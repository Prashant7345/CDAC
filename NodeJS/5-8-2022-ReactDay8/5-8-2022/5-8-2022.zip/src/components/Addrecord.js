import React,{useRef,useEffect} from 'react'
import axios from 'axios';

//useNavigate will help us to perform redirection process
import { useNavigate } from "react-router-dom";

export default function Addrecord() {
    //for navigation purpose
    let navigate = useNavigate();

    //hold textbox values in x1,x2 ref variable
    var x1 = useRef();
    var x2 = useRef();

    //on button click add record in database through node js
    var myfunc = ()=>{
        console.log('TEST');

        // console.log(x1);
        // console.log(x2);
        // received values from textboxes using ref variable
        console.log(x1.current.value);
        console.log(x2.current.value);

        //prepare an object which is expected in Node js UserModel
        var record = {
            username:x1.current.value,
            userage:x2.current.value
        }

        console.log(record);
        console.log(axios);

        //set your node js  or c# or java api path
        var apiPath = 'http://localhost:4500/users';

        //perform post method for insertion operation
        axios
        .post(apiPath,record)
        .then(res=>{
            console.log("res From Node Js");
            console.log(res);

            //redirect to /show-user after success
            navigate("/show-record");
        })
    }

    useEffect(()=>{
        return()=>{
            console.log('WILL UNMOUNT');
        }
    },[])

  return (
    <div className='container'>
        <h1>Add record</h1>

        <input type="text" ref={x1} className='form-control' /> <br />
        <input type="text"  ref={x2} className='form-control' /> <br />
        <button onClick={myfunc}> Add </button>
    </div>
  )
}

import React from 'react'

export default function About() {
  return (
    <div className='container'>
        <h1>About Page</h1>
    </div>
  )
}

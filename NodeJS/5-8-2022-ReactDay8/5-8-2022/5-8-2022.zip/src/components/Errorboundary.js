import React, { Component } from 'react'

export default class Errorboundary extends Component {
    constructor(props){
        super(props);
        this.state = {
            hasError:false
        }
    }
    componentDidCatch(error, errorInfo){
        console.log(error);
        console.log(errorInfo);
    }

    static getDerivedStateFromError(error) {
        return {hasError:true}
    }

  render() {
    if(this.state.hasError){
        return (
            <span className='text-center text-danger display-4'>
                Image Not Found
            </span>
        )

    }
    return this.props.children; 

  }
}

import React from 'react';

function Footer(){
    return(
        <p className='footer'>&copy; 2022 CDAC </p>
    )
}

export default Footer;
import React from 'react';

import axios from 'axios';

class Lifecycle4 extends React.Component{
    constructor(){
        console.log('CONST');
        super();

        this.state = {
            apidata:[],
            catDataFromText:"",
            status:false
        }

        this.catname = React.createRef();
    }

    componentDidMount(){
        console.log('DID MOUNT');
        axios
        .get('https://fakestoreapi.com/products')
        .then((res)=>{
            console.log(res);
            this.setState({
                apidata:res.data
            })
        })
        ///
        // document.body.addEventListener('click' , this.myfunc);
        ///
    }

    myfunc(){
        console.log('Clicked' , Math.random());
    }

    componentDidUpdate(){
        if(this.state.status){
            console.log('DID UPDATE');
            console.log(this.state.catDataFromText);

            var path =`https://fakestoreapi.com/products/category/${this.state.catDataFromText}`;

            console.log(path);

            axios
            .get(path)
            .then(res=>{
                console.log(res.data);
                this.setState({
                    apidata:res.data,
                    status:false
                })
            })
        }
    }

    componentWillUnmount(){
        console.log('WILL UNMOUNT');
        // document.body.removeEventListener('click' , this.myfunc);
    }

    myfunc2(){
        // console.log(this.catname);
        var data = this.catname.current.value;
        console.log(data);

        this.setState({
            catDataFromText:data,
            status:true
        })
    }

    render(){
        console.log('RENDER');

        const API = this.state.apidata;
        return(
            <div className='container'>
                <h1> Show Data From API</h1>

                <hr />
                <input type="text" ref={this.catname} />
                <button onClick={()=>{ this.myfunc2() }}>Click</button>
                <hr/>
                <div className='row'>
                    {
                        API && API.map(obj=>
                            <div className='col-xl-3 text-center border'>
                                <h2>{obj.price}</h2>
                                <p>{obj.title}</p>
                            </div>    
                        )
                    }
                </div>
            </div>
        )
    }
}

export default Lifecycle4;

/*
    hooks no class and this object
    no life cycle
    functional programming
    simple
    props,state,ref,.......

    class-- unsimilar logics presents in same cycle
    ......
*/
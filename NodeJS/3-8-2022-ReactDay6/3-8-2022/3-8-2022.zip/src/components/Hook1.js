import React, { useState } from 'react';
function Hook1(){
    var[count,setCount] =  useState(0);
    var[user,setUser] = useState(['user1','user2','user3']);
    var[product,setProduct] = useState({name:'shirt',price:1000})
    // count as as state variable
    // setCount ==> as a dispatcher func==> this.setState()
    // myfunc(){} ==>in class componner

    var myfunc2 = ()=>{
        // setProduct({name:"Jeans"})
        setProduct({...product , name:"Jeans"})
        // {name:'shirt',price:1000 ,  name:"Jeans"}
    }

    var myfunc = ()=>{
        console.log('YES');
        //this.setState({count:1})
        setCount(count+1)
    }
    var myfunc1 = ()=>{
        // setUser(['userx','usery'])
        // setUser([...user, 'userx','usery'])

        // console.log(user);
        // user[1] = 'test';
        // console.log(user);
        // setUser([...user]);
        // setUser
        // ['user1','user2','user3' ,'userx','usery']
    }
    return(
        <div className='container'>
            <h1>Hook1 </h1>
            <p> Count Value : {count} </p>
            <ul>
                {
                    user && user.map(val=>
                        <li>{val}</li>    
                    )
                }
            </ul>
            
                <p>
                    Name : {product.name} , Price : {product.price}
                </p>
                <p>
            <button onClick={myfunc}>Update</button>
                <button onClick={myfunc1}>Updateuser</button>
                <button onClick={myfunc2}>Update Product</button>
            </p>
        </div>
    )
}
export default Hook1;
/*
    const(){
        super();
        this.state = {
            count:0
        }
    }
    ////////////////////////////
    this.setState({count:1})
    <p> Count Value : {this.state.count} </p>

*/
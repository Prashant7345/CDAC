require('./db/mongodb');
const bodyParser = require('body-parser');
require('dotenv').config();
const express = require('express');

const userR = require('./routes/userRoute');
const taskR = require('./routes/taskRoute');

const app = express();
app.set('view engine' , 'ejs');
app.use(bodyParser.urlencoded()); // req.body form
app.use(bodyParser.json()); // req.body json

//http://localhost:4500/users
app.use('/users' , userR);
app.use('/task',taskR);


app.listen(process.env.PORT , ()=>{
    console.log('Running');
})
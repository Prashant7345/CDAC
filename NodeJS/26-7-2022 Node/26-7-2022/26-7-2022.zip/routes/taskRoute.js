const express = require('express');
const router = express.Router();

const taskC = require('../controllers/taskController');

router
.get('/email',taskC.emailPage)
.post('/email-action',taskC.emailActionPage)
.get('/validation',taskC.validationPage)
.post('/validation-action' , taskC.validationActionFunction)
.get('/fileupload',taskC.fileuploadPage)
.post('/upload-action' , taskC.uploadActionFunction)

module.exports = router;
const express = require('express');
const router = express.Router();

const userC = require('../controllers/userController');


//http://localhost:4500/users/12nm3m1n2m3n12n3

router
.get('/',userC.selectRecord)
.get('/:userid',userC.selectByIdRecord)
.post('/',userC.insertRecord)
.put('/:userid',userC.updateRecord)
.delete('/:userid',userC.deleteRecord)

module.exports = router;
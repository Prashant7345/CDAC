//https://nodemailer.com/about/
const nodemailer = require("nodemailer");
//https://www.npmjs.com/package/validator
var validator = require('validator');

//https://www.npmjs.com/package/multer
const multer  = require('multer');

//set file destination & filename with uniqueness
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads/')
    },
    filename: function (req, file, cb) {
     
      cb(null, Date.now() + file.originalname);
    }
});
//<input type="file" name="userprofile" /> <br>
const upload = multer({ storage: storage }).single('userprofile');

const emailPage = (req,res)=>{
    res.render('taskPage');
}
const validationPage = (req,res)=>{
    res.render('taskPage');
}
const fileuploadPage = (req,res)=>{
    res.render('taskPage');
}

// EMAIL

async function main(email,subject,message) {
    // Generate test SMTP service account from ethereal.email
    // Only needed if you don't have a real mail account for testing
    // let testAccount = await nodemailer.createTestAccount();
  
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        /*
            smtp.gmail.com 
            Requires SSL: Yes Requires TLS: Yes (if available) Requires Authentication: Yes Port for SSL: 465 Port for TLS/STARTTLS: 587

            http:// https://
            SSL--YES--465
            TLS--NO--587

            xyz.com
            mail.xyz.com
        */
      host: "mail.php-training.in",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'suraj@php-training.in', // generated ethereal user
        pass: 'Suraj@#123', // generated ethereal password
      },
      tls: {
        // do not fail on invalid certs
        rejectUnauthorized: false,
      },
      name:'php-training.in'
    });
  
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: '<suraj@php-training.in>', // sender address
      to: email, // list of receivers
      subject: subject, // Subject line
      text: "Hello world?", // plain text body
      html: message, // html body
    });
  
    console.log("Message sent: %s", info.messageId);
    // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
  
    // Preview only available when sending through an Ethereal account
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
  }

//EMAIL

const emailActionPage = (req,res)=>{
    // console.log(req.body);
    var email = req.body.emailid;
    var subject = req.body.subject;
    var message = req.body.message;

    
    main(email,subject,message).catch(console.error);
    res.send({msg:"ACTION CALLED"})
}

const validationActionFunction = (req,res)=>{
    console.log(req.body);
    //{username,usermobile,useremailid,userpassword,usercpassword}

    if( validator.isEmpty(req.body.username) || !validator.isAlpha(req.body.username,'en-IN'))
    {
        res.send({msg:'Invalid Username'})

    }
    else if(validator.isEmpty(req.body.usermobile) ||  !validator.isMobilePhone(req.body.usermobile,'en-IN') ){
        res.send({msg:'Invalid Mobile Number'})
    }
    else if(validator.isEmpty(req.body.useremailid) || !validator.isEmail(req.body.useremailid) ){
        res.send({msg:'Invalid Email id'})
    }

    else if(validator.isEmpty(req.body.userpassword) || !validator.isAlphanumeric(req.body.userpassword , 'en-IN') || !validator.isLength(req.body.userpassword,{min:4, max: 8}) ){
        res.send({msg:'Invalid Password'});
    }
    else if(!validator.equals(req.body.userpassword, req.body.usercpassword)){
        res.send({msg:'Invalid Confirm Password'});
    }
    else{
        // console.log ( Math.round( Math.random() * 10000 ) );
        res.send({msg:"DO REGISTER"})

        /*
            userM.findone({email:req.body.email})
            userM.save() -->insert

            validator.matches(req.body.userpassword, /^$/);

            FORGOT PASS:
            ------------------
            1) create a textbox with your emailid or mobile
        
            2) send otp on email using nodemailer or SMS API --> console.log ( Math.round( Math.random() * 10000 ) );

            3) lets have new form where user will pass otp , in text box

            4) compare your otp from user and generated otp

            5) if yes -- move to new form where u will be having 2 textbox with password & confirm password
        */
    }
}

const uploadActionFunction = (req,res)=>{
    // res.send({msg:"ACTION CALLED"})

    upload(req, res, function (err) {
        if (err instanceof multer.MulterError) {
          // A Multer error occurred when uploading.
          console.log(err);
        } else if (err) {
          // An unknown error occurred when uploading.
        }
    
        // Everything went fine.
        // req.file is the `avatar` file
        // req.body will hold the text fields, if there were any  
        console.log(req.body);
        console.log(req.file);
        if(req.file.size > 2*1000000){
            res.send({msg:"FILE UPTO 2MB"})
        }
        else{
            res.send({msg:"FILE UPLOADED"})
        }
      })
}

module.exports = {
    emailPage,
    validationPage,
    fileuploadPage,
    emailActionPage,
    validationActionFunction,
    uploadActionFunction
}
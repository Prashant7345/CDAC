const userM = require('../models/userModel');

const insertRecord = async (req,res)=>{
    var userData = req.body;
    // console.log(userData); // {name:'',age:''}
    // //create an instance of modelname
    try{
        var instance = new userM(userData);
        var ans_db = await instance.save();
        res.send({msg:ans_db})
    }
    catch(err){
        throw err;
    }
}
const updateRecord = async(req,res)=>{
    // console.log(req.body);
    // console.log(req.params); //{userid:45678d9sds4d5678}
    // res.send({msg:"update"})
    try{
        var ans_db = await userM.findByIdAndUpdate(req.params.userid , req.body);
        res.send({msg:ans_db});
    }
    catch(err){
        throw err;
    }
}

const selectRecord = async(req,res)=>{
    //https://mongoosejs.com/docs/api.html#model_Model-find
    try{
        var ans_db = await userM.find();
        res.send({msg:ans_db});
    }
    catch(err){
        throw err;
    }
}
const deleteRecord = async(req,res)=>{
    // console.log(req.params); // {userid:1123nm12n3m23m1b3}
    try{
        var ans_db = await userM.findByIdAndRemove(req.params.userid);
        res.send({msg:ans_db});
    }
    catch(err){
        throw err;
    }
}
const selectByIdRecord = async(req,res)=>{
    //http://localhost:4500/users/12nm3m1n2m3n12n3
    var user_id = req.params.userid; //{userid:12nm3m1n2m3n12n3}
    // console.log(user_id);
    try{
        var ans_db= await userM.findById(user_id);
        res.send({msg:ans_db})
    }
    catch(err){
        throw err;
        // res.send({msg:"No Data Exist"})
    }
}
module.exports = {
    insertRecord,
    updateRecord,
    selectRecord,
    deleteRecord,
    selectByIdRecord
}
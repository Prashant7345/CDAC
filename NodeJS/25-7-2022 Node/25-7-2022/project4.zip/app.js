require('./db/mongodb');
const bodyParser = require('body-parser');
require('dotenv').config();
const express = require('express');

const userR = require('./routes/userRoute');

const app = express();
app.use(bodyParser.urlencoded()); // req.body form
app.use(bodyParser.json()); // req.body json

//http://localhost:4500/users
app.use('/users' , userR);


app.listen(process.env.PORT , ()=>{
    console.log('Running');
})
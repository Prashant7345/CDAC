require('dotenv').config();
const express = require('express');
//npm i body-parser
const bodyParser = require('body-parser');

const productR = require('./routes/productRoute');

const app = express();

app.set('view engine' , 'ejs'); // npm i ejs

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/products' , productR);

app.listen(process.env.PORT , ()=>{
    console.log('RUNNING');
})
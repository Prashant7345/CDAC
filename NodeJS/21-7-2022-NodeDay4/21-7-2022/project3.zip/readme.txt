npm init -y

index.js

scripts": {
    "start": "nodemon index.js"
}

ASYNC Promise
ASYNC Async Await
fetch() -- Javascript
HTTP axios 
Mongo DB -- NODE Connection

CRUD API ----

FILE UPLOAD
EMAIL HANDLING
----------------------------------
REACT --- 
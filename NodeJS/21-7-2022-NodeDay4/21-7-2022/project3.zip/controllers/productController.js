const db = require('../db/mysqldb');


const updateData = (req,res)=>{
    //.put('/:userid',productC.updateData)
    console.log(req.body);
    console.log(req.params);

    db.query('UPDATE users SET username = ?, usersalary = ? WHERE id = ?', [req.body.username, req.body.usersalary, req.params.userid] , function(err,results){
        if(err) throw err;
        res.send({msg:results});
    });
}

const insertData = (req,res)=>{
    //https://expressjs.com/en/5x/api.html#req.body
    console.log(req.body); 
    // Undefined without body-parser middleware
    //{username:'s',usersalary:2000} if you use bodyParse.urlencoded();
    var postValue = {
        id:'',username:req.body.username , usersalary:req.body.usersalary
    }
    //https://www.npmjs.com/package/mysql
    /*
        db.query(`insert into users SET ? ` , postValue , function(err,results){
            if(err) throw err;
            res.send({msg:results});
        });
    */
    var username = req.body.username;
    var usersal = req.body.usersalary;

    db.query(`insert into users (username,usersalary) values ('${username}','${usersal}') ` ,  function(err,results){
        if(err) throw err;
        res.send({msg:results});
    });
    // res.send({msg : "POST ROUTE CALLED"});
}

//http://localhost:4500/products/13 (DELETE)
// .delete('/:userid',productC.deleteData)
const deleteData = (req,res)=>{
    console.log(req.params); //{userid:13}
    db.query(`DELETE FROM users WHERE id=${req.params.userid} `, function(err,results){
        if(err) throw err;
        res.send({msg:results})
    });
    // res.send({msg:'DELETE ROUTE CALLED'});
}


const selectData = (req,res)=>{
    db.query('SELECT * FROM users ' , function(err,results){
        if(err) throw err;
        res.send({msg:results});
    });
}

const insertProductForm = (req,res)=>{
    res.render('AddRecord')
}

//http://localhost:4500/products/5 (URL -- GET)
// .get('/:userid',productC.selectDataById)
const selectDataById = (req,res)=>{
    console.log(req.params);
    db.query(`SELECT * FROM users WHERE id=${req.params.userid}` , function(err,results){
        if(err) throw err;
        res.send({msg:results});
    });
}

module.exports = {
    updateData,insertData,deleteData,selectData,insertProductForm,selectDataById
}
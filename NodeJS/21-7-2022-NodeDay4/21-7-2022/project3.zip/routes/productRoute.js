const express = require('express');
const router = express.Router();

const productC = require('../controllers/productController');

router
.get('/',productC.selectData)
//http://localhost:4500/products/5 (URL -- GET)
.get('/addProduct',productC.insertProductForm)

.get('/:userid',productC.selectDataById)

.post('/',productC.insertData)
.put('/:userid',productC.updateData)

//http://localhost:4500/products/13 (DELETE)
.delete('/:userid',productC.deleteData)

//http://localhost:4500/products/addProduct

module.exports  = router;
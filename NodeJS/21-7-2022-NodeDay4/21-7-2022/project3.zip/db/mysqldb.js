const mysql = require('mysql');

const connection = mysql.createConnection({
    host:process.env.HOST,
    user:process.env.USER,
    password:'',
    database:process.env.DATABASE
});

module.exports =connection; 
import React, { Component } from 'react'
import C2 from './C2'

export default class C1 extends Component {
  render() {
    return (
      <div>CHild Comp 1 <br />
      <hr />
      <C2 x2={this.props.x1}/>
      </div>
    )
  }
}

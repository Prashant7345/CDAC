import React, { Component } from 'react'
import axios from 'axios';
export default class Right extends Component {
    constructor(){
        super();
        this.state = {
            api:[]
        }
    }
    componentDidUpdate(prevProps){
        if(this.props.x2 !== prevProps.x2){
            console.log('DIDUPDATE' , this.props.x2 , prevProps.x2);
            axios.get('https://fakestoreapi.com/products/category/'+this.props.x2).then(res=>{
                console.log(res.data);
                this.setState({
                    api:res.data
                })
            });
        }
        
    }
    componentDidMount(){
        axios.get('https://fakestoreapi.com/products').then(res=>{
            // console.log(res.data);
            this.setState({
                api:res.data
            })
        });
    }
  render() {
    const API=this.state.api;
    return (
      <div className='border'>
        <h1> Right : {this.props.x2} , {this.state.caname}</h1>
        <div className='row'>
            {
                API && API.map(obj=>
                    <div className='col-xl-3'>
                        <img src={obj.image} className='img-fluid' />
                    </div>

                )
            }
        </div>
      </div>
    )
  }
}

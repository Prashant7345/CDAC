import React, { Component } from 'react'
import { Provider } from '../Providers/FirstProvider';
import C1 from './C1'



export default class Parentcomponent extends Component {

    constructor(){
        super();
        //lets bind this keyword in myfunc
        this.myfunc = this.myfunc.bind(this);

        this.uname = React.createRef();
        this.state = {
            user:''
        }

        //creating Context for Data transfer
        // this.xyz = React.createContext();
        // console.log(this.xyz);
        // console.log(typeof this.xyz.Provider);
        // console.log(this.xyz.Provider);
    }

    myfunc(){
        console.log('TEST');
        console.log(this);
        console.log(this.uname);
        console.log(this.uname.current.value);
        this.setState({
            user:this.uname.current.value
        });
    }

    // myfunc = () => {    
    //     console.log('this is:', this);  
    // }

  render() {
    return (
      <div className='container'>
         PARENT Component <br />
         <input type="text" ref={this.uname} />
         {/* <button onClick={()=>{ this.myfunc() }}>Send</button> */}
         <button onClick={this.myfunc}>Send</button>
         <hr />


         {/* implement Provider Her */}

         <Provider value={this.state.user}>
            <C1  x1={this.state.user}/>
         </Provider>
      </div>
    )
  }
}

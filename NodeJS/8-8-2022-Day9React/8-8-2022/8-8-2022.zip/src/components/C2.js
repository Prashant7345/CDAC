import React, { Component } from 'react'
import C3 from './C3'

export default class C2 extends Component {
  render() {
    return (
      <div>Child Comp <br />
      <hr />
        <C3 x3={this.props.x2}/>
      </div>
    )
  }
}

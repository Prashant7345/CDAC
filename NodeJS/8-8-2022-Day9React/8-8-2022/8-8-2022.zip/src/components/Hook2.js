import React ,{useEffect,useState} from 'react'

export default function Hook2() {

    const[count , setCount] = useState(0);
    const[no , setNo] = useState(304);

    var myfunc = function(){
        // alert()
        setCount(count+1)
    }
    var myfunc1 = function(){
        // alert()
        setNo(no +2 )
    }

    /*
    //This is acting as a didmount cycle on page load , did update cycle after state change
    useEffect(()=>{
        console.log('Use Effect Called' , Math.random() );
    });  
    
    //use useEffect() as a didmount cycle only
    useEffect(()=>{
        console.log('Use Effect Called' , Math.random() );
    },[]);
    */

    /*
    //use useEffect() as a didmount cycle & will unmount cycle
    useEffect(()=>{
        console.log('Use Effect Called' , Math.random() );

        return ()=>{
            console.log('Will Unmount Cycle');
        }
    },[]);
    */

    // useEffect(()=>{
    //     console.log('USe Effect' , Math.random());
    // },[count,no]);

    // useEffect(()=>{}) --- execute on page load & after every state change 
    // useEffect(()=>{},[]) --- execute only on page load

    // useEffect(()=>{},[count]) --- execute on page load & if there is a change is count state variable

    // useEffect(()=>{},[count,no]) --- execute on page load & if there is a change is count,no state variable

    // useEffect(()=>{  return()=>{}  } , []) --- execute on page load & act as a willunmount cycle 

  return (
    <div className='container'>
        <h1>Hook - State , use Effect</h1>

        <p>
            Cunt Value : {count}
        </p>
        <button onClick={myfunc}>Enter</button>

        <p>
            No : {no}
        </p>
        <button onClick={myfunc1}>Enter</button>
    </div>
  )
}

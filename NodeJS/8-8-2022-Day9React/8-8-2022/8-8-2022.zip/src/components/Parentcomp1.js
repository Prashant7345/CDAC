import React, { Component } from 'react'
import Left from './Left';
import Right from './Right';

export default class Parentcomp1 extends Component {
    constructor(){
        super();
        this.state = {
            categoryname:'Anonymous'
        }
        this.methodFromParent = this.methodFromParent.bind(this);
    }

    methodFromParent(dataFromLeft){
        // console.log('Data Transfer Methd Called' , dataFromLeft);
        // console.log(this);
        this.setState({
            categoryname:dataFromLeft
        });
    }

  render() {
    return (
      <div className='container'>
        <div className='row'>
            <div className='col-xl-3'>
                <Left x1={this.methodFromParent}/>
            </div>
            <div className='col-xl-9'>
                <Right x2={this.state.categoryname}/>
            </div>
        </div>
      </div>
    )
  }
}

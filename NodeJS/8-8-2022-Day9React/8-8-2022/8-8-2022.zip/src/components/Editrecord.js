import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

export default function Editrecord() {
  //redirect
  let navigate = useNavigate();
  //use ref variable for update process
  
  //create state variable for holding values fromdb
  const[name,setName] = useState('');
  const[age,setAge] = useState('');

  let params = useParams();
  console.log(params); //{idFromDatabase:21jk3h123h1h3212}

  var uid = params.idFromDatabase;
  console.log(uid);

  useEffect(()=>{
    var apiPath = 'http://localhost:4500/users/'+uid;
    console.log(apiPath);

    axios
    .get(apiPath)
    .then(res=>{
      // console.log('response fromnode');
      // console.log(res.data);
      console.log(res.data.msg); // {_id:'',username:'',userage:''}

      setName(res.data.msg.username)
      setAge(res.data.msg.userage)
    })

  },[]);

  var update = ()=>{

    var data = {
      username:name,
      userage:age
    }

    console.log(data);

    var apiPath = 'http://localhost:4500/users/'+uid;
    console.log(apiPath);

    axios
    .put(apiPath , data)
    .then(res=>{
      console.log('ResAfter Update');
      console.log(res);
      //
      navigate('/show-record');
    })
  }

  var myfunc1 = (e)=>{
    console.log(e);
    console.log(e.target.value);
    setName(e.target.value)
  }
  return (
    <div className='container'>
        <h1>Edit Record</h1>

        <input type="text" value={name} onChange={myfunc1} />
        
        <input type="text"  value={name} onChange={(e)=>{ setName(e.target.value) }} className='form-control' /> <br />

        <input type="text"  value={age} onChange={ (e)=>{ setAge(e.target.value) } } className='form-control'/> <br />
        
        <button onClick={update}>UPdate</button>
        {name}, {age}
    </div>
  )
}

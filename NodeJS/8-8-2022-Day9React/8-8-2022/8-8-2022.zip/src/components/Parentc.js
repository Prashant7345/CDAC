import React, { Component } from 'react'
import Errorboundary from './Errorboundary'
import Imagec from './Imagec'



export default class Parentc extends Component {
  render() {
    return (
      <div className='container'>
        <div className='row'>
            <Errorboundary>
                <Imagec path="https://rukminim1.flixcart.com/image/612/734/kbwjvrk0/watch/q/r/p/wn03139-wanton-original-imaft5n6ugzgmezt.jpeg?q=50" />
            </Errorboundary>

            <Errorboundary>            
            <Imagec path="https://rukminim1.flixcart.com/image/612/734/kerfl3k0pkrrdj/watch/2/5/r/1170-bl-br-fogg-original-imafvhvvagrufhkw.jpeg?q=50"/>

            </Errorboundary>
            <Errorboundary>
            
            <Imagec path="https://rukminim1.flixcart.com/image/612/734/jwzabgw0/watch/c/h/g/ls2821-limestone-original-imafhjcr3xkxgqaz.jpeg?q=50"/>

            </Errorboundary>
            <Errorboundary>
                <Imagec path=""/>
            </Errorboundary>
        </div>
      </div>
    )
  }
}

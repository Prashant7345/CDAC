import React,{useState,useEffect,useRef} from 'react'

export default function Hook3() {
    //setState()
    const[name , setName] = useState('Anonymous');

    var x1 =useRef();
    //this.x1 = React.createRef();
    var myfunc = ()=>{
        // alert()
        console.log(x1);
        console.log(x1.current.value);
        //this.setState({name:....})
        setName(x1.current.value);
    }

    // useEffect(()=>{
    //     //DID MOUNT(once) , DID UPDATE(state variable)
    //     console.log('USE EFFECT EXAMPLE' , Math.random());
    // });

    // useEffect(()=>{
    //     //DID MOUNT(once)
    //     console.log('USE EFFECT EXAMPLE' , Math.random());
    // },[]);

    // useEffect(()=>{
    //     //DID MOUNT(once),will unmount cycle
    //     console.log('USE EFFECT EXAMPLE' , Math.random());

    //     return ()=>{
    //         console.log('WILL UNMOUNT');
    //     }
    // },[]);


    useEffect(()=>{
        //DID MOUNT(once),will unmount cycle
        console.log('USE EFFECT EXAMPLE' , Math.random());
        
    },[name]);

  return (
    <div className='container'>
        <h1>Hooks Example</h1>
        <p>
            <input type="text" ref={x1} />
            <button onClick={myfunc}>Change</button>
        </p>
        <p>
            USERNAME : {name}
        </p>
    </div>
  )
}

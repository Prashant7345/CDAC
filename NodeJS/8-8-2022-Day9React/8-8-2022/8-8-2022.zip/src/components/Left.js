import React, { Component } from 'react'

export default class Left extends Component {

    constructor(){
        super();
        this.caname = React.createRef();
    }

    myfunc = ()=>{
        // console.log('Click');
        // console.log(this.caname);
        var textBoxValue = this.caname.current.value;
        console.log('Category Name' , textBoxValue);
        console.log(this.props.x1);

        this.props.x1(textBoxValue);
        //<Left x1={this.methodFromParent}/>
    }

  render() {
    return (
      <div className='border'>
        <input type="text" ref={this.caname}/>
        <button onClick={this.myfunc}>Send</button>
      </div>
    )
  }
}

import React, { Component } from 'react'
import { Consumer } from '../Providers/FirstProvider'



export default class C3 extends Component {
  render() {
    return (
      <div>
        Child CCOmp 3: 
        <p>
            Data From Parent Comp : {this.props.x3}
        </p>
        <p>
            Data From Provider:
            <Consumer>
                {
                    value => (
                        <b> {value } </b>
                    )
                }
            </Consumer>
        </p>
      </div>
    )
  }
}

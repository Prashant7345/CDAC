import React, { Component } from 'react'

export default class Imagec extends Component {
  render() {

    if(this.props.path == ""){
        throw new Error('Image Path Not Found');
    }

    return (
      <div className='col-xl-3 text-center'>
        <img src={this.props.path} className='img-fluid'/>
        <h2>2000</h2>
        <p>Product Name</p>
      </div>
    )
  }
}

import React from 'react';

const CONTEXT = React.createContext();

const Provider = CONTEXT.Provider;
const Consumer = CONTEXT.Consumer;

export {Provider,Consumer};
import React from 'react';

class Home extends React.Component{
    render(){
        return(
            <div className='container'>
                <h1>HOME Page</h1>
                <p>
                       Documentation and examples for Bootstrap’s powerful, responsive navigation header, the navbar. Includes support for branding, navigation, and more, including support for our collapse plugin.
                </p>
            </div>
        )
    }
}

export default Home;
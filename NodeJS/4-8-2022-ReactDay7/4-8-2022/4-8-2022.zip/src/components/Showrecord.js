import React,{useState,useEffect} from 'react'

import {Link} from 'react-router-dom';

import axios from 'axios';

export default function Showrecord() {

    //store api data in state variable
    const[api,setApi] = useState([]);

    var apiPath ='http://localhost:4500/users';

    useEffect(()=>{
        console.log('use effect called');

        axios
        .get(apiPath)
        .then(res=>{
            // console.log(res);
            console.log(res.data);
            setApi(res.data);
        });

    } ,[]);

  return (
    <div className='container'>
        <h1>Show record</h1>

        <hr />
        <input type="text" />
        <button>Search</button>
        <hr />
        <div className='row'>
            {
                api && api.map(obj=>
                    <div className='col-xl-3'>
                        <h1>{obj.username}</h1>
                        <h4>AGE : {obj.userage}</h4>
                        <p>{obj._id}</p>
                        <p>
                            <Link to='/edit'>Edit</Link> | 
                            <Link to={'/delete/'+obj._id}>Delete</Link> 
                            {/* <Link to={'/delete1/20/30'}>Delete</Link>  */}
                        </p>
                        {/* http://localhost:3000/delete/12312jh31kh3kjhkj */}
                    </div>    
                )
            }
        </div>
    </div>
  )
}

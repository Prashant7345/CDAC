import React from 'react'

export default function Editrecord() {
  return (
    <div className='container'>
        <h1>Edit Record</h1>
        <input type="text" className='form-control' /> <br />
        <input type="text"  className='form-control'/> <br />
        <button>UPdate</button>
    </div>
  )
}
